<?php
// The constant addends indicate the number of not-ignored tokens
// at that point, for easy counting.
$a = 2 + 3;
$a = $a + 6;
$a = $a + 9;
$a = $a + 12;
$a = $a + 15;
$a = $a + 18;
$a = $a + 21;
$a = $a + 24;
$a = $a + 27;
$a = $a + 30;
$a = $a + 33;
$a = $a + 36;
$a = $a + 39;
$a = $a + 42;
$a = $a + 45;
$a = $a + 48;
$a = $a + 51;
$a = $a + 54;
$a = $a + 57;
$a = $a + 60;
