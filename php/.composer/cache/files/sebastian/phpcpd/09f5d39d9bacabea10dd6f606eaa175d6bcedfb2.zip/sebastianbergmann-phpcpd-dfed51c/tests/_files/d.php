<?php
// The constant addends indicate the number of not-ignored tokens
// at that point, for easy counting.
$b = 2 + 3;
$b = $b + 6;
$b = $b + 9;
$b = $b + 12;
$b = $b + 15;
$b = $b + 18;
$b = $b + 21;
$b = $b + 24;
$b = $b + 27;
$b = $b + 30;
$b = $b + 33;
$b = $b + 36;
$b = $b + 39;
$b = $b + 42;
$b = $b + 45;
$b = $b + 48;
$b = $b + 51;
$b = $b + 54;
$b = $b + 57;
$b = $b + 60;
