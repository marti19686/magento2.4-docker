<?php

/**
 * This function returns an ASCII escape character:
 *
 * @return string
 */
function getAsciiEscapeChar()
{
    return "";
}
