# Quote Analytics Functional Tests

The Functional Test Module for **Magento Quote Analytics** module.
