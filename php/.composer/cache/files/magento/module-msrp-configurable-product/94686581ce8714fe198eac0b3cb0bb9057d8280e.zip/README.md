# MsrpConfigurableProduct

**MsrpConfigurableProduct** provides type and resolver information for the Msrp module from the ConfigurableProduct module.