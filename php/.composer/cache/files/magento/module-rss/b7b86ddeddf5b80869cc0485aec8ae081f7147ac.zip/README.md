Magento_Rss module is responsible for processing all RSS feeds of the application and allows to turn on/off RSS centrally.
