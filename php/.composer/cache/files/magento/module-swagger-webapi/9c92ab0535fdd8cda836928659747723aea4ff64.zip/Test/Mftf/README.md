# Swagger Webapi Functional Tests

The Functional Test Module for **Magento Swagger Webapi** module.
