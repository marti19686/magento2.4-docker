<?php
/**
 *
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Magento\Sales\Controller\Order;

use Magento\Sales\Controller\OrderInterface;

class PrintCreditmemo extends \Magento\Sales\Controller\AbstractController\PrintCreditmemo implements OrderInterface
{
}
