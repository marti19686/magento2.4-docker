Magento_UrlRewrite module provides ability to customize website URLs by creating custom URL rewrite rules.
