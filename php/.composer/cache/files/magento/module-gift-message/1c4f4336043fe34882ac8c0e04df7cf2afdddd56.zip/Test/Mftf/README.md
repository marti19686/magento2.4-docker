# Gift Message Functional Tests

The Functional Test Module for **Magento Gift Message** module.
