# Variable Functional Tests

The Functional Test Module for **Magento Variable** module.
