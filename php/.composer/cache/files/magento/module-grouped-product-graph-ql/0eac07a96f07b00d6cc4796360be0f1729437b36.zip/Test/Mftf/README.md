# Grouped Product Graph Ql Functional Tests

The Functional Test Module for **Magento Grouped Product Graph Ql** module.
