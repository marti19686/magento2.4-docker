## Overview
 
The Magento_CmsUrlRewrite module adds support for URL rewrite rules for CMS pages. See also Magento_UrlRewrite module. 

The module adds and removes URL rewrite rules as CMS pages are added or removed by a user.
The rules can be edited by an admin user as any other URL rewrite rule. 
