# Customer Import Export Functional Tests

The Functional Test Module for **Magento Customer Import Export** module.
