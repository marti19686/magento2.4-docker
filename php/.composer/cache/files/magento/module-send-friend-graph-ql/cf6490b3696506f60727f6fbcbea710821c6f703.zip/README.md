# SendFriendGraphQl

**SendFriendGraphQl** provides support of GraphQL for SendFriend functionality.
