# Eav Graph Ql Functional Tests

The Functional Test Module for **Magento Eav Graph Ql** module.
