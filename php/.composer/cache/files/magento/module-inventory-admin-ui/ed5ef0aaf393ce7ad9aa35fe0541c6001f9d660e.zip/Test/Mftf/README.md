# Inventory Admin Ui Functional Tests

The Functional Test Module for **Magento Inventory Admin Ui** module.
