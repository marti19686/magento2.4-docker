# UrlRewriteGraphQl

**UrlRewriteGraphQl** provides type information for the GraphQl module
to generate url rewrites from entities that implement such rewrites,
like categories, products or cms and other 3rd party modules.
