# SalesGraphQl

**SalesGraphQl** provides type and resolver information for the GraphQl module
to generate sales orders information.
