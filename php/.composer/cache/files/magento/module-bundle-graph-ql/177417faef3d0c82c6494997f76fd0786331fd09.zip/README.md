# BundleGraphQl

**BundleGraphQl** provides type and resolver information for the GraphQl module
to generate bundle product information.
