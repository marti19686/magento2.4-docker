# Reports Functional Tests

The Functional Test Module for **Magento Reports** module.
