# Persistent Functional Tests

The Functional Test Module for **Magento Persistent** module.
