# WishlistGraphQl

**WishlistGraphQl** provides type information for the GraphQl module
to generate wishlist fields.
