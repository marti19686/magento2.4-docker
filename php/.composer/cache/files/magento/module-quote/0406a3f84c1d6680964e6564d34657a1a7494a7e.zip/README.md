# Overview
## Purpose of module


# Deployment
## System requirements

The Magento_Quote module does not have any specific system requirements.

## Install
The Magento_Quote module is installed automatically (using the native Magento install mechanism) without any additional actions.
