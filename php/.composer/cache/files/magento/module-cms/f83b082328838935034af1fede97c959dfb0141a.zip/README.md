# CMS Module

The CMS module provides the create, edit, and manage functionality on pages for different content types.

## UI components

### Wysiwyg

The Wysiwyg UI component is a customizable and configurable TinyMCE4 editor.

The default implementation has the following customizations:

* Magento Media Library support