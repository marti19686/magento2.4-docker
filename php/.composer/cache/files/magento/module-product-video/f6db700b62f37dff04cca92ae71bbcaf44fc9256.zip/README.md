The Magento_ProductVideo module implements functionality related with linking video files from external resources to product.
