# Ui Functional Tests

The Functional Test Module for **Magento Ui** module.
