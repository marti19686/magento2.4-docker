The Magento_Fedex implements the integration with the FedEx shipping carrier.
