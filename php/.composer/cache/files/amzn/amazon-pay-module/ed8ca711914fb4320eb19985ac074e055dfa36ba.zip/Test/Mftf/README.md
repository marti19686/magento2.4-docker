# Amazon Payment Functional Tests

Functional Test Module for Amazon Payment modules.