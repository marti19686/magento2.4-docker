<?php

namespace Dotdigitalgroup\Email\Controller\Product;

class Related extends \Dotdigitalgroup\Email\Controller\Edc
{
}
