<?php

namespace Dotdigitalgroup\Email\Controller\Quoteproducts;

class Crosssell extends \Dotdigitalgroup\Email\Controller\Edc
{
}
