<?php

namespace Dotdigitalgroup\Email\Controller\Quoteproducts;

class Upsell extends \Dotdigitalgroup\Email\Controller\Edc
{
}
