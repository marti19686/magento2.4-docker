<?php

namespace Dotdigitalgroup\Email\Controller\Email;

class Coupon extends \Dotdigitalgroup\Email\Controller\Edc
{
}
