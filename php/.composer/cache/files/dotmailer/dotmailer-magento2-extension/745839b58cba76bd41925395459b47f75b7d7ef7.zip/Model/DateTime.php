<?php

namespace Dotdigitalgroup\Email\Model;

class DateTime extends \DateTime
{
}