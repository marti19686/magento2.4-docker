<?php

namespace Dotdigitalgroup\Chat\Model\Api;

interface LiveChatRequestInterface
{
}
