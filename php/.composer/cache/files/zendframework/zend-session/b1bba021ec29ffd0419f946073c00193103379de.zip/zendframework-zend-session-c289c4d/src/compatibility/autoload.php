<?php
/**
 * @see       https://github.com/zendframework/zend-session for the canonical source repository
 * @copyright Copyright (c) 2005-2019 Zend Technologies USA Inc. (https://www.zend.com)
 * @license   https://github.com/zendframework/zend-session/blob/master/LICENSE.md New BSD License
 * @deprecated
 */

/**
 * Legacy purposes only, to prevent code that references it from breaking.
 */
trigger_error('Polyfill autoload support (file library/Zend/Session/compatibility/autoload.php) is no longer necessary;'
. ' please remove your require statement referencing this file', E_USER_DEPRECATED);
