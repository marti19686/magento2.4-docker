# zend-psr7bridge

[![Build Status](https://secure.travis-ci.org/zendframework/zend-psr7bridge.svg?branch=master)](https://secure.travis-ci.org/zendframework/zend-psr7bridge)

Code for converting [PSR-7](http://www.php-fig.org/psr/psr-7/) messages to
[zend-http](https://github.com/zendframework/zend-http) messages, and vice
versa.

**Note: This project is a work in progress.**

- Issues: https://github.com/zendframework/zend-psr7bridge/issues
- Documentation: https://zendframework.github.io/zend-psr7bridge/
