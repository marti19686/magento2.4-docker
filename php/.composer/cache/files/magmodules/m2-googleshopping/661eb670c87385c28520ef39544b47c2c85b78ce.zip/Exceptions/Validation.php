<?php
/**
 * Copyright © Magmodules.eu. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Magmodules\GoogleShopping\Exceptions;

use Magento\Framework\Exception\StateException;

class Validation extends StateException
{

}
