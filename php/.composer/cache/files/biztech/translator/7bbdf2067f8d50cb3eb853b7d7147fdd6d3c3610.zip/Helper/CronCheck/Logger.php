<?php
/** Copyright © 2016 store.biztechconsultancy.com. All Rights Reserved. **/

namespace Biztech\Translator\Helper\CronCheck;

class Logger extends \Monolog\Logger
{

}
