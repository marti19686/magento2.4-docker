================
Authors of PHPMD
================

Main Authors/Maintainers
------------------------

- Manuel Pichler (Since 2009)
- Marc Würth (Since 2014) / https://github.com/ravage84

Contributors
------------

- Volker Dusch (Since 2010) / https://github.com/edorian
- timmartin (Since 2010) / https://github.com/timmartin
- Sebastian Bergmann (Since 2011) / https://github.com/sebastianbergmann
- Zsolt Takacs (Since 2011) / https://github.com/zstakacs
- Che Hodgins (Since 2011) / https://github.com/chehodgins
- Gennadiy Litvinyuk (Since 2011) / https://github.com/gennadiylitvinyuk
- Francis Besset (Since 2011) / https://github.com/francisbesset
- zerkalica (Since 2012) / https://github.com/zerkalica
- palbertini (Since 2012) / https://github.com/palbertini
- bahulneel (Since 2012) / https://github.com/bahulneel
- Willem Stuursma (Since 2012) / https://github.com/willemstuursma
- Nimlhug (Since 2012) / https://github.com/Nimlhug
- A. Martin Llano (Since 2012) / https://github.com/amllano
- Juan Basso (Since 2012) / https://github.com/jrbasso
- Brian Ridley (Since 2013) / https://github.com/ptlis
- Radosław Mejer (Since 2014) / https://github.com/radmen
- Tobias Nyholm (Since 2014) / https://github.com/Nyholm
- Gasillo (Since 2014) / https://github.com/Gasillo

..
   Local Variables:
   mode: rst
   fill-column: 79
   End:
   vim: et syn=rst tw=79
