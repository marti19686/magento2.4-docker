<?php

namespace StripeIntegration\Payments\Helper;

class Quote
{
    public $quoteId = null;
}
